#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <stdbool.h>

typedef struct Alunos
{
    int matricula;
    char nome[30];
    float nota_1, nota_2, nota_3;
    float media;
    struct Alunos *prox;
} aluno_t;

aluno_t *primeiro_aluno(char *nome, int matricula, float nota_1, float nota_2, float nota_3)
{
    aluno_t *novo = (aluno_t *)malloc(sizeof(aluno_t));
    if (!novo)
    {
        printf("Erro ao alocar mem�ria.\n");
        exit(1);
    }

    strncpy(novo->nome, nome, 30);
    novo->matricula = matricula;
    novo->nota_1 = nota_1;
    novo->nota_2 = nota_2;
    novo->nota_3 = nota_3;
    novo->media = (float)(novo->nota_1 + novo->nota_2 + novo->nota_3) / 3.0;
    novo->prox = NULL;

    return novo;
}

void novo_aluno(aluno_t *primeiro, char *nome, int matricula, float nota_1, float nota_2, float nota_3)
{
    aluno_t *atual = primeiro;

    // Percorre a lista at� encontrar o �ltimo elemento
    while (atual->prox != NULL)
    {
        atual = atual->prox;
    }

    // Cria um novo aluno
    aluno_t *novo = (aluno_t *)malloc(sizeof(aluno_t));
    if (!novo)
    {
        printf("Erro ao alocar mem�ria.\n");
        exit(1);
    }

    strncpy(novo->nome, nome, 30);
    novo->matricula = matricula;
    novo->nota_1 = nota_1;
    novo->nota_2 = nota_2;
    novo->nota_3 = nota_3;
    novo->media = (float)(novo->nota_1 + novo->nota_2 + novo->nota_3) / 3.0;
    novo->prox = NULL;

    // Adiciona o novo aluno ao final da lista
    atual->prox = novo;
}

void listar(aluno_t *lista){
    // Itera pela lista e imprimi os dados de cada aluno
    aluno_t *atual = lista;
    while (atual != NULL)
    {
        printf("Matr�cula:\t%d\tAluno:\t%s\n", atual->matricula, atual->nome);
        printf("Nota 01:\t%.2f\tNota 02:\t%.2f\n", atual->nota_1, atual->nota_2);
        printf("Nota 03:\t%.2f\tM�dia Geral:\t%.2f\n\n", atual->nota_3, atual->media);
        
        atual = atual->prox;
    }	
	
}

void busca_sequencial(aluno_t *lista, int valor){
    int passadas = 0;
    aluno_t *atual = lista;
    bool localizado = false;
	while (atual != NULL)
	{
	   
	    if(atual->matricula == valor){
	    	localizado = true;
	        printf("%s localizado na posi��o %d.\n", atual->nome, passadas + 1);
	        printf("Ap�s %d passadas.", passadas + 1);
	        break;
	        
	    }
	     passadas++;
		atual = atual->prox;
	}
	if(!localizado){
		printf("Matr�cula %d fora do range da lista!\nEfetuado %d passadas\n", valor, passadas);
	}

}

int tamanhoLista(aluno_t *lista) { //definindo o tamanho da lista encadeada
    int tamanho = 0;
    while (lista != NULL) {
        tamanho++;
        lista = lista->prox;
    }
    return tamanho;
}

int* ConverterVetor(aluno_t *lista, int tamanho) { //busca bin�ria em lista encadeada � loucura... S� loko... Num compensa!
    int *vetor = (int*) malloc(tamanho * sizeof(int));
    int i = 0;

    while (lista != NULL) {
        vetor[i] = lista->matricula;
        lista = lista->prox;
        i++;
    }

    return vetor;
}


int buscaBinaria(int arr[], int tamanho, int valor, int *passadas) {
    int inicio = 0;
	int fim = tamanho - 1;
	int meio = 0;
    *passadas = 0; // Inicializa o contador
    
	printf("\n\t\tDEBUGANDO\n\n");
	printf("In�cio:\t%d\tMeio:\t%d\tFim:\t%d\n", inicio, meio, fim);
	
	
    while (inicio <= fim) {
        (*passadas)++; // Incrementa a cada itera��o
        meio = inicio + (fim - inicio) / 2;

        if (arr[meio] == valor){
        	 return meio;
		}
        if (valor < arr[meio]){
        	fim = meio - 1;
		}
        else{
        	inicio = meio + 1;
		}
            
        
        printf("In�cio:\t%d\tMeio:\t%d\tFim:\t%d\tPasso:\t%d\n", inicio, meio, fim, *passadas);
    }
    printf("\n");
    return -1;
}

void buscaBinariaLista(aluno_t *lista, int valor) {
    int tamanho = tamanhoLista(lista);
    int *vetor = ConverterVetor(lista, tamanho);

    int passadas;
    int posicao = buscaBinaria(vetor, tamanho, valor, &passadas);
    
    // Buscando os dados da lista encadeada.
    aluno_t *atual = lista;
    int contador = 0;
    while (atual != NULL && contador < posicao) {
        atual = atual->prox;
        contador++;
    }
    
    if (posicao != -1 && atual != NULL) {
	   printf("%s localizado na posi��o %d.\n", atual->nome, posicao + 1);
	   printf("Ap�s %d passadas.", passadas + 1);
    } else {
        printf("Matr�cula %d fora do range da lista!\nEfetuado %d passadas\n", valor, passadas);
    }

    free(vetor);
}


int main()
{
	setlocale(LC_ALL, "");
	
    aluno_t *lista = primeiro_aluno("Natanael", 1, 9.7, 9.5, 10);

    novo_aluno(lista, "Alice Silva", 2, 7.5, 8.0, 6.5);
    novo_aluno(lista, "Bruno Souza", 3, 9, 7, 8.5);
    novo_aluno(lista, "Carla Oliveira", 4, 6.0, 7.5, 8);
    novo_aluno(lista, "Daniel Costa", 5, 8.5, 9.5, 7);
    novo_aluno(lista, "Eduarda Mendes", 6, 6.5, 7, 6);
    novo_aluno(lista, "Felipe Pereira", 7, 8, 9.0, 8.5);
    
    listar(lista);
     printf("\n\n\n");
	//ALGORITMOS DE BUSCAS
    busca_sequencial(lista, 6);
    printf("\n\n\n");
    buscaBinariaLista(lista, 6);
    


    return 0;
}
