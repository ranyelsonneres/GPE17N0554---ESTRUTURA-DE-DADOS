#include <stdio.h>
#define TAM 6

typedef struct {
    int matricula;
    char nome[50];
    float notas[3];
} Aluno;

float media(Aluno aluno) {
    float soma = 0;
    for (int i = 0; i < 3; i++) {
        soma += aluno.notas[i];
    }
    return soma / 3;
}

int busca_aluno(Aluno alunos[], int tam, int matriculaBusca) {
    int comparacoes = 0;
    
    for (int i = 0; i < tam; i++) {
        comparacoes++;
        if (alunos[i].matricula == matriculaBusca) {
            printf("Numero de iterações feitas: %d\n", comparacoes);
            return i;
        }
    }
    return -1;
}

int comparaMatricula(const void *a, const void *b) {
    return ((Aluno*)a)->matricula - ((Aluno*)b)->matricula;
}

int busca_aluno_binaria(Aluno alunos[], int n, int matriculaBusca) {
    int comparacoes = 0;
    int esquerda = 0;
    int direita = n - 1;
    
    while (esquerda <= direita) {
        comparacoes++;
        int meio = (esquerda + direita) / 2;
        
        if (alunos[meio].matricula == matriculaBusca) {
            printf("Número de comparações: %d\n", comparacoes);
            return meio;
        } else if (alunos[meio].matricula < matriculaBusca) {
            esquerda = meio + 1;
        } else {
            direita = meio - 1;
        }
    }
    printf("Aluno não encontrado\n");
    return -1;
}

int main() {
    Aluno alunos[TAM] = {
        {1, "Alice Silva", {7.5, 8.0, 6.5}},
        {2, "Bruno Souza", {9.0, 7.0, 8.5}},
        {3, "Carla Oliveira", {6.0, 7.5, 8.0}},
        {4, "Daniel Costa", {8.5, 9.5, 7.0}},
        {5, "Eduarda Mendes", {6.5, 7.0, 6.0}},
        {6, "Felipe Pereira", {8.0, 9.0, 8.5}}
    };
    
    int resultado = busca_aluno_binaria(alunos, TAM, 5);
    if (resultado != -1) {
        printf("Aluno encontrado: %s e está com a média = %.2f\n", alunos[resultado].nome, media(alunos[resultado]));
    } else {
        printf("Aluno não encontrado.\n");
    }

    return 0;
}
